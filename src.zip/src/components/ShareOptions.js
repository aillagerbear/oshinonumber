import React, { useState } from 'react';
import { Copy } from 'lucide-react';

const sharePlatforms = [
  { name: 'Instagram', url: 'https://www.instagram.com/' },
  { name: 'Twitter', url: 'https://twitter.com/intent/tweet?text=' },
  { name: 'Facebook', url: 'https://www.facebook.com/sharer/sharer.php?u=' },
  { name: 'Discord', url: 'https://discord.com/channels/@me' },
];

const shareTemplates = [
  "내 최애 사진을 넣었더니 복권 번호가 나왔다?! 이 번호로 진짜 당첨될까? 😆",
  "최애 사진으로 복권 번호 뽑아보는 거 나만 해본 거 아님? 여러분도 한번 도전해보세요!",
  "내 최애 덕질하다가 이 번호를 받았는데... 이번 주말 복권 사야겠죠? 😏",
  "복권번호 뽑아준 최애가 나중에 '내가 너 복권 당첨되게 해줬지?' 하겠지? 😂",
];

const hashtags = ['#복권', '#최애', '#덕질', '#행운의번호', '#당첨기원', '#운빨', '#복권덕후', '#최애덕질', '#로또', '#행운번호'];

const getRandomTemplate = () => shareTemplates[Math.floor(Math.random() * shareTemplates.length)];

const getRandomHashtags = (count) => {
  const shuffled = hashtags.sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count).join(' ');
};

const ShareOptions = ({ onClose, lotteryNumbers, pensionLotteryNumbers, serviceUrl }) => {
  const [copySuccess, setCopySuccess] = useState(false);
  const shareText = `${getRandomTemplate()} 🔢 로또: ${lotteryNumbers.join(', ')}, 연금복권: ${pensionLotteryNumbers.join('-')} ${getRandomHashtags(3)}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareText).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 w-96 max-w-full">
        <h3 className="text-xl font-semibold mb-3">결과 공유하기</h3>
        <div className="space-y-2">
          {sharePlatforms.map((platform) => {
            let shareUrl = platform.url;
            if (platform.name !== 'Instagram' && platform.name !== 'Discord') {
              shareUrl += `${encodeURIComponent(shareText)}&url=${encodeURIComponent(serviceUrl)}`;
            }
            return (
              <a
                key={platform.name}
                href={shareUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded text-center"
              >
                {platform.name}에 공유하기
              </a>
            );
          })}
          <button
            onClick={copyToClipboard}
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded flex items-center justify-center"
          >
            <Copy className="mr-2" size={18} />
            {copySuccess ? '복사됨!' : '공유 텍스트 복사'}
          </button>
        </div>
        <button
          onClick={onClose}
          className="mt-3 w-full bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded"
        >
          닫기
        </button>
      </div>
    </div>
  );
};

export default ShareOptions;